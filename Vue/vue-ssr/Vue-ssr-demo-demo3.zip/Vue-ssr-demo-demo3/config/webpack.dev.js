module.exports = {
  mode: 'development',
  // 原始源代码（仅限行）
  devtool: 'cheap-module-eval-source-map'
}
