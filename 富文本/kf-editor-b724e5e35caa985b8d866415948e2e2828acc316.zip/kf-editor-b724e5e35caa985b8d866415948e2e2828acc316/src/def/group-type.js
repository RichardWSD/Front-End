/*!
 * 组类型
 */

define( function () {

    return {

        "GROUP": "kf-editor-group",
        "VIRTUAL": "kf-editor-virtual-group"

    };

} );