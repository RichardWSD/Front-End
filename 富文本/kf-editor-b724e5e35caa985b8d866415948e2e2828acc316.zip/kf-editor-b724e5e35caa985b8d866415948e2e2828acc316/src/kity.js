/**
 * 数学公式Latex语法解析器
 */

define( function () {

    return window.kity;

} );

