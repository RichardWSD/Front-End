KityFormula Editor
=======
基于 SVG 的公式编辑器，百度前端富应用小组开发

当前文档工作未完善，有疑惑之处请发邮件联系我们。

email:kity@baidu.com