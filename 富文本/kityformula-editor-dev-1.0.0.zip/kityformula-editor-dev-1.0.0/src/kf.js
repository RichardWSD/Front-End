/**
 * Created by hn on 14-3-12.
 */

define( function () {

    return window.kf;

} );