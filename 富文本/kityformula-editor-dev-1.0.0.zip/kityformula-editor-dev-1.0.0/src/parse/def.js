/**
 * 定义了一个转换对照表
 */

define( function () {

    return {

        "radical": true,
        "fraction": true,
        "summation": true,
        "integration": true,
        "placeholder": true,
        "script": true,
        "superscript": true,
        "subscript": true,
        "brackets": true

    };

} );