/*!
 * toolbar元素类型定义
 */

define( function ( require ) {

    return {
        "DRAPDOWN_BOX": 1,
        "AREA": 2,
        "DELIMITER": 3
    };

} );