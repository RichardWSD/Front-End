/*!
 * 组元素类型定义
 */

define( function ( require ) {

    return {
        "BIG": 1,
        "SMALL": 2
    };

} );