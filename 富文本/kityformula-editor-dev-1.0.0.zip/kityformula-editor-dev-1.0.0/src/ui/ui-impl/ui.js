/**
 * Created by hn on 14-3-31.
 */

define( function ( require ) {

    return {

        DrapdownBox: require( "ui/ui-impl/drapdown-box" ),
        Delimiter: require( "ui/ui-impl/delimiter" ),
        Area: require( "ui/ui-impl/area" )

    };

} );