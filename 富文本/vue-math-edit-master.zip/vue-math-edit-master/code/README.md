### 安装必要模块
```
npm install
```

### 本地运行
```
npm run serve
```

### 生产打包
```
npm run build
```
