/**
 * Created by hn on 14-7-28.
 */

var KFE_UI_CONFIG = {

    clazz: 'Panel',
    className: 'kfe-editor',
    widgets: [

        {
            clazz: 'Panel',
            className: 'kfe-toolbar',
            widgets: [ {
                
            } ]
        },

        {
            clazz: 'Panel',
            className: 'kfe-edit-area'
        }

    ]

};