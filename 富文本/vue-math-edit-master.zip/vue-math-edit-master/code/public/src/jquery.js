/**
 * Created by hn on 14-3-31.
 */

define( function () {
    return window.jQuery;
} );