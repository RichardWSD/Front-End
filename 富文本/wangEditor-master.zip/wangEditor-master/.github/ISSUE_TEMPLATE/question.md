---
name: 使用时遇到了问题（非 bug）
about: 请按照该模板填写，以便我们能真正了解你的问题，否则该 issue 将不予受理！
---

## 问题描述

*请输入遇到的问题...*

## wangEditor 版本

*请输入内容……*

## 是否查阅了文档 ？

（文档链接 [http://www.wangeditor.com/doc](http://www.wangeditor.com/doc/) ）

*是/否*

## 最小成本的复现步骤

（请告诉我们，如何**最快的**复现该问题？）

- 步骤一
- 步骤二
- 步骤三

