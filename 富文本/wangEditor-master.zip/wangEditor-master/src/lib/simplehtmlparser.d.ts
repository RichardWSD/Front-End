/**
 * @description typescript 声明文件
 * @author wangfupeng
 */

declare class SimpleHtmlParser {
    parse(html: string, opt: any): void
}
export default SimpleHtmlParser
