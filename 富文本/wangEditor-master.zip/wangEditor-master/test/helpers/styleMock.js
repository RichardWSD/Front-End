/**
 * @description 图片拖拽事件绑定
 * @author xiaokyo
 */

module.exports = {
    process() {
        return ''
    },
}
